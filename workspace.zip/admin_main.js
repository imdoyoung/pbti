// SIDEBAR: SUBMENU
const allSidebarSubmenu = document.querySelectorAll('#sidebar .sidebar__submenu')

allSidebarSubmenu.forEach(item => {
    const a = item.previousElementSibling

    a.addEventListener('click', function(e) {
        e.preventDefault()

        if (this.classList.contains('clicked')) {
            this.classList.remove('clicked')
            item.classList.remove('active')
        } else {
            allSidebarSubmenu.forEach(i => {
                i.previousElementSibling.classList.remove('clicked')
                i.classList.remove('active')
            })

            this.classList.add('clicked')
            item.classList.add('active')
        }
    })
})



// SIDEBAR: DROPDOWN MENU
const allSidebarDropdownMenu = document.querySelectorAll('#sidebar .sidebar__dropdown-menu')

allSidebarDropdownMenu.forEach(item => {
    const a = item.previousElementSibling

    a.addEventListener('click', function(e) {
        e.preventDefault()

        if (item.classList.contains('active')) {
            item.classList.remove('active')
            this.classList.remove('active')
        } else {
            allSidebarDropdownMenu.forEach(i => {
                i.previousElementSibling.classList.remove('active')
                i.classList.remove('active')
            })

            item.classList.add('active')
            this.classList.add('active')
        }
    })
})




// MAIN: DROPDOWN
const allMainDropdown = document.querySelectorAll('#main .main__top .main__top__menu .main__dropdown')

allMainDropdown.forEach(item => {
    const a = item.previousElementSibling

    a.addEventListener('click', function(e) {
        e.preventDefault()

        if (item.classList.contains('active')) {
            item.classList.remove('active')
        } else {
            allMainDropdown.forEach(i => {
                i.classList.remove('active')
            })

            item.classList.add('active')
        }
    })
})







// MAIN: MAIN BODY MENU
const allMainBodyMenu = document.querySelectorAll('#main .main__body :is(.members__menu, .sales-summary__menu) .menu')

allMainBodyMenu.forEach(item=> {
    const icon = item.previousElementSibling

    icon.addEventListener('click', function () {
        if(item.classList.contains('active')) {
            item.classList.remove('active')
        } else {
            allMainBodyMenu.forEach(i=> {
                i.classList.remove('active')
            })

            item.classList.add('active')
        }
    })
})







// DOCUMENT EVENT
document.addEventListener('click', function(e) {
    if (!e.target.matches('#sidebar, #sidebar *')) {
        allSidebarSubmenu.forEach(item => {
            item.previousElementSibling.classList.remove('clicked')
            item.classList.remove('active')
        })
    }

    if (!e.target.matches('#sidebar, #sidebar *, #sidebar-mobile .toggle-sidebar')) {
        sidebar.classList.remove('active')
    }

    if (!e.target.matches('#main .main__top .main__top__menu, #main .main__top .main__top__menu *')) {
        allMainDropdown.forEach(item => {
            item.classList.remove('active')
        })
    }

    if (!e.target.matches('#main .main__body :is(.members__menu, .sales-summary__menu), #main .main__body :is(.members__menu, .sales-summary__menu) *')) {
        allMainBodyMenu.forEach(item => {
            item.classList.remove('active')
        })
    }
})







// CHART: APEXCHART

const salesData = {
  labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
  datasets: [{
    label: '매출',
    data: [2000000, 1700000, 2400000, 2800000, 4100000, 3400000],
    backgroundColor: 'rgba(54, 162, 235, 0.2)',
    borderColor: 'rgba(54, 162, 235, 1)',
    borderWidth: 1,
    lineTension: 0,
    pointRadius: 5,
    pointBackgroundColor: 'white',
    pointBorderColor: 'rgba(54, 162, 235, 1)',
    pointBorderWidth: 2
  }]
};

const membersData = {
  labels: ['1월', '2월', '3월', '4월', '5월', '6월'],
  datasets: [{
    label: '가입자수',
    data: [160, 203, 230, 260, 195, 210],
    backgroundColor: 'rgba(255, 99, 132, 0.2)',
    borderColor: 'rgba(255, 99, 132, 1)',
    borderWidth: 1,
    lineTension: 0,
    pointRadius: 5,
    pointBackgroundColor: 'white',
    pointBorderColor: 'rgba(255, 99, 132, 1)',
    pointBorderWidth: 2
  }]
};

const salesCtx = document.querySelector('.sales-chart').getContext('2d');
const salesChart = new Chart(salesCtx, {
  type: 'line',
  data: salesData,
  options: {
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          // y축 눈금 설정
          stepSize: 1000000,
          callback: function(value, index, values) {
            return value.toLocaleString() + '원';
          }
        }
      }
    }
  }
});

const membersCtx = document.querySelector('.members-chart').getContext('2d');
const membersChart = new Chart(membersCtx, {
  type: 'line',
  data: membersData,
  options: {
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          // y축 눈금 설정
          stepSize: 100,
          callback: function(value, index, values) {
            return value.toLocaleString() + '명';
          }
        }
      }
    }
  }
});


//delivery
// You can use this JS code to change the delivery status dynamically based on user actions
const deliveryStatusBoxes = document.querySelectorAll('.delivery-status-box');
deliveryStatusBoxes.forEach((box) => {
  box.addEventListener('click', () => {
    deliveryStatusBoxes.forEach((box) => {
      box.classList.remove('active');
    });
    box.classList.add('active');
  });
});

